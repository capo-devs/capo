#ifndef AL_BYTE_H
#define AL_BYTE_H

#include <cstddef>
#include <cstdint>
#include <limits>
#include <type_traits>

using uint = unsigned int;

namespace al {

using byte = unsigned char;

} // namespace al

#endif /* AL_BYTE_H */
